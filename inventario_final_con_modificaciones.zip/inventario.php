// inventario.php actualizado con submenú y botón de recibo si es maquinaria usada.
